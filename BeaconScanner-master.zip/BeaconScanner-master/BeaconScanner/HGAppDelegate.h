//
//  HGAppDelegate.h
//  Beacon Scanner
//
//  Created by HUGE | Mike Welles on 4/4/14.

#import <Cocoa/Cocoa.h>

@interface HGAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
