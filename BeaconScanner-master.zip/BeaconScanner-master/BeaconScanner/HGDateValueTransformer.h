//
//  HGDateValueTransformer.h
//  Beacon Scanner
//
//  Created by HUGE | Mike Welles on 4/10/14.
//  Copyright (c) 2014 Huge, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HGDateValueTransformer : NSValueTransformer

@end
